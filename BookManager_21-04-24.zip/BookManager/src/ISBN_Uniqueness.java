import java.util.HashSet;
import java.util.List;
import java.util.Set;
 
public class ISBN_Uniqueness {
    private Set<String> isbnSet;
 
    public ISBN_Uniqueness(List<Book> existingBooks) {
        isbnSet = new HashSet<>();
        for (Book book : existingBooks) {
            isbnSet.add(book.getisbn());
        }
    }
 
    public boolean isISBNUnique(String isbn) {
        return isbnSet.contains(isbn);
    }
 
    // Method to add a new book to the collection and update the ISBN set
    public void addBook(Book newBook) {
        isbnSet.add(newBook.getisbn());
    }
 
//     Method to remove a book from the collection and update the ISBN set
    public void removeBook(Book bookToRemove) {
        isbnSet.remove(bookToRemove.getisbn());
    }
 
    // Main method to test uniqueness check
    public static void main(String[] args) {
    	
        List<Book> existingBooks = Book.readBooksFromCSV("BooksData.csv");    // Create a list of existing books
 
        // initialization of BookManager with existing books
        ISBN_Uniqueness bookManager = new ISBN_Uniqueness(existingBooks);
 
        // Check uniqueness of an ISBN
        String newISBN = "9780333791037";
        boolean isUnique = bookManager.isISBNUnique(newISBN);
        System.out.println("Is ISBN unique? " + isUnique);
 
    }
}