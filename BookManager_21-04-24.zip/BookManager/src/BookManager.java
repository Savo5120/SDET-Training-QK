import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.ArrayList;
 
public class BookManager {
    private Set<String> isbnSet;
 
    public BookManager(List<Book> existingBooks) {
        isbnSet = new HashSet<>();
        if (existingBooks != null) {
            for (Book book : existingBooks) {
                isbnSet.add(book.getisbn());
            }
        }
    }
 
    public int uploadBooks(String filePath) {
        int booksAdded = 0;
        int skippedBooks = 0;
 
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] attributes = line.split(",");
                if (attributes.length >= 5) { // Ensure attributes array has enough elements
                    String isbn = attributes[4]; // Assuming ISBN is at index 4
                    if (!isbnSet.contains(isbn)) {
                        // If ISBN is unique, add the book to the collection
                        Book newBook = new Book(attributes[0], attributes[1], attributes[2], attributes[3], isbn, attributes[4]);
                        addBook(newBook);
                        booksAdded++;
                    } else {
                        // If ISBN is not unique, skip the book
                        skippedBooks++;
                    }
                } else {
                    // Handle unexpected input (e.g., missing attributes)
                    System.out.println("Invalid input format: " + line);
                    skippedBooks++;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
 
        System.out.println("Books added: " + booksAdded);
        System.out.println("Skipped books (due to duplicate ISBNs or invalid format): " + skippedBooks);
 
        return booksAdded;
    }
 
    // Method to add a new book to the collection and update the ISBN set
    public void addBook(Book newBook) {
        isbnSet.add(newBook.getisbn());
    }
 
    // Method to remove a book from the collection and update the ISBN set
    public void removeBook(Book bookToRemove) {
        isbnSet.remove(bookToRemove.getisbn());
    }
 
    // Main method (for testing)
    public static void main(String[] args) {
        // Create a list of existing books (if any)
        List<Book> existingBooks = new ArrayList<>(); // Initialize with an empty list if there are no existing books
 
        // Initialize BookManager with existing books
        BookManager bookManager = new BookManager(existingBooks);
 
        // Specify the path to the file containing books to be uploaded
        String filePath = "books_to_upload.csv";
 
        // Upload books from the file and get the number of books added
        int booksAdded = bookManager.uploadBooks(filePath);
        System.out.println("Total books added: " + booksAdded);
    }
}